//write a c program to check file exists or not
#include<stdio.h>
int main(){
       FILE*file;

       file=fopen("likitha.txt","r");
	     if(file==NULL){
		   printf("file does not exist\n");
	     }else{
		   printf("file exists\n");
		   fclose(file);
	     }
	     return 0;
       }