#include<stdio.h>
int main(){
	int i;
	int arr[10]={5,7,8,10,56,58,45};
	for(i=0;i<10;i++){
	       printf("%d\t",arr[i]);
	       }
	return 0;
	}
