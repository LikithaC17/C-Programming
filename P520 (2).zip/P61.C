#include<stdio.h>
int main(){
  FILE*file;
  char data[500];

  printf("Enter data to write to the file\n");
  gets(data);

  file=fopen("output.txt","w");
  if(file==NULL){
      printf("Error opening file!\n");
      return 1;
  }
  fprintf(file,"%s",data);
  fclose(file);

  printf("Data written to file successfully\n");
  return 0;
}
