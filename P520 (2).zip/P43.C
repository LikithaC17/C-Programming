#include<stdio.h>
int main(){
	int i;
	int arr[5]={7,8,5,3,10};
	for(i=4;i>=0;i--){
	     printf("%d\t",arr[i]);
	     }
	return 0;
	}