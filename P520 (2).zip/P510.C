#include<stdio.h>
void swap(int *a,int *b){
       int temp=*a;
	      *a=*b;
	      *b=temp;
       }
void main(){
      int x=10;
      int y=20;
      swap(&x,&y);
      printf("after swap:x=%d,y=%d\n",x,y);
}
