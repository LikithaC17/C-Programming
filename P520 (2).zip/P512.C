#include<stdio.h>
void main(){
      int *ptr=NULL;
      ptr=NULL;
      if(ptr==NULL){
      printf("pointer is null");
      }
}