#include<stdio.h>
int main(){
       FILE*file;
       char data[500];

       printf("Enter a line to append:\n");
       gets(data);

       file=fopen("output.txt","a");
       if(file ==NULL){
	       printf("Error opening file!\n");
	       return 1;
       }
       fprintf(file,"\n%s,",data);
       fclose(file);
       printf("line append successfully\n");
       return 0;
}
