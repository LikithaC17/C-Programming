#include<stdio.h>
int main(){
    FILE*file;
    //char data[500];
    int lines=0;
    char ch;

   // printf("enter the line to append:\n");
   // gets(data);

    file=fopen("output.txt","rt");
    if(file == NULL){
	    printf("error opening file!\n");
	    return 1;
    }
    while((ch =fgetc(file))!=EOF){
	  putchar(ch);
	  if(ch=='\n'){
	  lines++;
	  printf("newline found current count:%d\n",lines);
	  }
    }
    fclose(file);
    printf("total numder of lines:%d\n",lines+1);
    return 0;
    }
