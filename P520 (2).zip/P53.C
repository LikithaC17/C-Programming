#include<stdio.h>
int main(){
     char str[]="hello,world!";
     int length=strlen(str);
     printf("Length of the string:%d\n",length);
     return 0;
}