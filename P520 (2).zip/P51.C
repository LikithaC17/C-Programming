#include<stdio.h>
void main(){
      char str[100];
      printf("Enter a String:");
      gets(str);
      printf("you Entered:%s\n",str);
}