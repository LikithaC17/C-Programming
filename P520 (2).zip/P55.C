#include<stdio.h>
int main(){
	char str[100];
	int i=0;

	printf("Enter a String");
	gets(str);

	while(str[i]!=0){
	      if(str[i] == ' '){
		     str[i]='_';
		     }
		     i++;
	      }
	      printf("Modified String:%s\n",str);
	return 0;
	}
