#include<stdio.h>
int main(){
	 int arr[10]={5,7,3,1,9,11,13};

	 int i;
	 for(i=0;i<5;i++){
		printf("%d",arr[i]);
		}
	 return 0;
	 }