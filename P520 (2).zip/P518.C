#include<stdio.h>
void main(){
      int*ptr=(int*)malloc(1000000000*sizeof(int));
      if(ptr == NULL){
	      printf("memory allocation failed\n");
      }else{
	      printf("memory allocation succeeded\n");
	      free(ptr);
      }
}