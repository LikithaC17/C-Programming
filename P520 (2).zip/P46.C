#include<stdio.h>
int main(){
	int i;
	int arr[5],sum=0;
		printf("enter the number\n:");
		for(i=0;i<5;i++){
		       scanf("%d",&arr[i]);
		       sum+=arr[i];
		}
		printf("sum of elements:%d",sum);
		return 0;
	 }


