#include<stdio.h>
void main(){
      int num = 10, *ptr;
      ptr=&num;
      printf("address of num:%u\n",ptr);
}