#include<stdio.h>
#include<string.h>
void main(){
	 char str1[100],str2[100];
	 clrscr();
	 printf("enter a first string");
	 gets(str1);
	 printf("enter a second string");
	 gets(str2);
	 strcpy(str2,str1);
	 printf("concatinated string:%s\n");
	 }
