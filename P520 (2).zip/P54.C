#include<stdio.h>
int main(){
       int length=0,i=0;
       char str[100];
       //int len=strlen(str);
       printf("Enter the String\n");
       gets(str);

       while(str[i]!=0){
	     length++;
	     i++;
       }
       printf("The length of the string is:%d\n",length);
       return 0;
       }