#include<stdio.h>
//function returning a value

//function declaration with a return type
int multiply(int a,int b);

int main(){
      int result=multiply(4,3); //function call with parameter
      printf("multipication of %d\n",result);
      return 0;
}
//function definitions with parameters
int multiply(int a,int b){
	return a*b;//returning the result of multiptication
}
